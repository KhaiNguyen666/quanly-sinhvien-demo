import pytest

from manager import StudentManager
from student import Student


@pytest.fixture
def manager():
    m = StudentManager()
    m.add_student(Student("SV001", "Nguyen Van An", 8.0))
    m.add_student(Student("SV002", "Tran Thi Binh", 6.0))
    return m


def test_add_and_find(manager):
    assert manager.find_by_id("SV001").name == "Nguyen Van An"
    assert manager.find_by_id("XXX") is None


def test_add_duplicate_raises(manager):
    with pytest.raises(ValueError):
        manager.add_student(Student("SV001", "Trung ma", 5.0))


def test_remove(manager):
    assert manager.remove_student("SV002") is True
    assert manager.remove_student("SV002") is False
    assert len(manager.students) == 1


def test_average_gpa(manager):
    assert manager.average_gpa() == 7.0


def test_average_gpa_empty():
    assert StudentManager().average_gpa() == 0.0


def test_top_student(manager):
    assert manager.top_student().student_id == "SV001"


def test_search_by_name(manager):
    assert len(manager.search_by_name("binh")) == 1


def test_invalid_gpa():
    with pytest.raises(ValueError):
        Student("SV009", "Sai", 11)


def test_save_and_load(manager, tmp_path):
    path = str(tmp_path / "out.json")
    manager.save(path)
    other = StudentManager()
    other.load(path)
    assert [s.student_id for s in other.students] == ["SV001", "SV002"]
